package com.example.bookify

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.bookify.databinding.ActivityMainBinding
import com.example.bookify.databinding.LayoutHomeBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    val activity = this
    val list :ArrayList<BooksModel> = ArrayList()
    val adapter = BooksAdapter(list,activity)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        binding.apply {
            mRecyclerViewHome.adapter = adapter
            list.add(BooksModel(R.drawable.book_1,"Book_Title","Book_Description","sample_book.pdf"))
            list.add(BooksModel(R.drawable.book_2,"Book_Title","Book_Description","sample_book.pdf"))
            list.add(BooksModel(R.drawable.book_3,"Book_Title","Book_Description","sample_book.pdf"))
            list.add(BooksModel(R.drawable.book_4,"Book_Title","Book_Description","sample_book.pdf"))
            list.add(BooksModel(R.drawable.book_5,"Book_Title","Book_Description","sample_book.pdf"))

        }


        }
    }
