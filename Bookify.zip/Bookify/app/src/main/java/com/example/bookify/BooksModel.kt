package com.example.bookify

data class BooksModel (
 val image: Int,
 val title: String,
 val description: String,
 val bookPDF : String,

)
